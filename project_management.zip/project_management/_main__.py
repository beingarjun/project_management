from .formulas import cost_variance

def main():
    print("Cost Variance:", cost_variance())

if __name__ == "__main__":
    main()
