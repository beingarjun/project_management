# project_management_formula/formulas.py

def cost_variance(ev: float, ac: float) -> float:
    """Cost Variance (CV): EV - AC"""
    return ev - ac

def schedule_variance(ev: float, pv: float) -> float:
    """Schedule Variance (SV): EV - PV"""
    return ev - pv

def cost_performance_index(ev: float, ac: float) -> float:
    """Cost Performance Index (CPI): EV / AC"""
    if ac == 0:
        raise ValueError("Actual Cost (AC) cannot be zero")
    return ev / ac

def schedule_performance_index(ev: float, pv: float) -> float:
    """Schedule Performance Index (SPI): EV / PV"""
    if pv == 0:
        raise ValueError("Planned Value (PV) cannot be zero")
    return ev / pv

def total_float(ls: float, es: float) -> float:
    """Total Float: LS - ES"""
    return ls - es

def free_float(ef: float, es: float) -> float:
    """Free Float: EF - ES"""
    return ef - es

def estimate_at_completion(bac: float, cpi: float) -> float:
    """Estimate at Completion (EAC): BAC / CPI"""
    if cpi == 0:
        raise ValueError("CPI cannot be zero")
    return bac / cpi

def estimate_to_complete(eac: float, ac: float) -> float:
    """Estimate to Complete (ETC): EAC - AC"""
    return eac - ac
