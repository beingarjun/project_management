# Project Management Formula Library

A Python library that provides functions for commonly used project management calculations, such as Earned Value Management (EVM) metrics.

## Installation

```bash
pip install project_management_formula
